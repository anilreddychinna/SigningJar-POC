import java.io.File;
import java.security.KeyStore;

import net.jsign.AuthenticodeSigner;
import net.jsign.DigestAlgorithm;
import net.jsign.KeyStoreUtils;
import net.jsign.Signable;

/**
 * @author Anil Karre
 *
 */
public class WindowsAuthenticodeSigner {
	
	public AuthenticodeSigner processSign(File keystoreFile, String aliasName, String keyStorepassword,
			String jarFile)
			throws Exception {

		KeyStore keystore = KeyStoreUtils.load(keystoreFile, "JKS", keyStorepassword, null);
		System.out.println("keystore---getCertificate------"+keystore.getProvider().getInfo());
		System.out.println("keystore--getDefaultType-------"+keystore.getDefaultType());

		AuthenticodeSigner signer = new AuthenticodeSigner(keystore, aliasName, keyStorepassword);

		// Algorithm type
		signer.withDigestAlgorithm(DigestAlgorithm.SHA1);

		signer.withProgramName("My ESP Application")
		.withProgramURL("http://www.example.com")
		.withTimestamping(true)
		.withTimestampingAuthority("http://timestamp.comodoca.com/authenticode");

		Signable file = Signable.of(new File(jarFile));
		signer.sign(file);
		System.out.println("------------Signed Done-----------"+signer.toString());
		return signer;

	}

	public static void main(String[] args) throws Exception {

		String srmwyoming = System.getProperty("user.dir") + "/srm-wyoming.jar";
		String app1 = System.getProperty("user.dir") + "/app1.exe";
		String espCodeSigning = System.getProperty("user.dir") + "/EspCodeSigning.final.jks";


		File srmwyomingFile = new File(srmwyoming);
		File app1File = new File(app1);
		File espCodeSigningFile = new File(espCodeSigning);
		
		System.out.println(" --------------------------------------------------------");
		System.out.println(" file path ----: " + srmwyomingFile.getAbsolutePath());
		System.out.println(" file path ----: " + app1File.getAbsolutePath());
		System.out.println(" file path ----: " + espCodeSigningFile.getAbsolutePath());
		System.out.println(" --------------------------------------------------------");
		
		WindowsAuthenticodeSigner mainAuthenticodeSigner = new WindowsAuthenticodeSigner();
		System.out.println(" --------------------------------------------------------");
		AuthenticodeSigner authenticodeSigner = mainAuthenticodeSigner.processSign(espCodeSigningFile, "server", "J4dmin@ESP",
				app1);
		System.out.println(" --------------------------------------------------------");
		System.out.println(" -------------------------END-------------------------------");
		System.out.println(" -------------------------END-------------------------------"+authenticodeSigner.toString());

	}

}
